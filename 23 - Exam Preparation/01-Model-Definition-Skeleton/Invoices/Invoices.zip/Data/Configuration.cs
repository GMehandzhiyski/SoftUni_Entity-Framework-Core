﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
        "Server=.;Database = InvoicesUser; Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
