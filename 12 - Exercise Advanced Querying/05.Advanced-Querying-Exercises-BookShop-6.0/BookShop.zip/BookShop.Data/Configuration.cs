﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=.;Database=StudentSystem;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
