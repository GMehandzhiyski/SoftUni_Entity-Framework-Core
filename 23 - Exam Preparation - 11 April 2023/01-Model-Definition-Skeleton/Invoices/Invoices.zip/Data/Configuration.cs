﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
        "Server=.;Database= InvoicesUser;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
