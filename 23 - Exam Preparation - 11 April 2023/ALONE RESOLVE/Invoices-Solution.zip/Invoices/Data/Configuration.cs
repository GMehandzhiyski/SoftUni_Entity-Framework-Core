﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-H3STVF4\SQLEXPRESS;Database=Invoices2024;Integrated Security=True;Encrypt=False";
    }
}
