﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString =
        "Server=.;Database= MedicineDb ;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
