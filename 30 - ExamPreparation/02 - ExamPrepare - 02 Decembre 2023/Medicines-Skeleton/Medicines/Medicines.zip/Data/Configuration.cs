﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            "Server=.;Database= MedicineDB ;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
