﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            "Server=.;Database= CadastreDb ;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
