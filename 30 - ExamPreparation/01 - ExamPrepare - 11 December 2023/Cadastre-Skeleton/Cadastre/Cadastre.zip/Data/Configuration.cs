﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString =

            "Server=.;Database= CadastreDB ;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
