﻿using Cadastre.Data;

namespace Cadastre.DataProcessor
{
    public class Serializer
    {
        public static string ExportPropertiesWithOwners(CadastreContext dbContext)
        {
            return"";
        }

        public static string ExportFilteredPropertiesWithDistrict(CadastreContext dbContext)
        {
            return "";
        }
    }
}
