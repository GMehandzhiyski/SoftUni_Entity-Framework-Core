﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            "Server=.;Database=StudentSystem;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
