﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = 
        "Server=.;Database=Boardgames;User Id=sa;Password=Project123;TrustServerCertificate=true";
    }
}
