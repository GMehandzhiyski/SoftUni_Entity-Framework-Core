﻿namespace TravelAgency.DataProcessor.ExportDtos
{
    public class BookingExportDTO
    {
        public string TourPackageName { get; set; } = default!;

        public string Date { get; set; } = default!;
    }
}