﻿namespace TravelAgency.Data.Models.Enums
{
    public enum Language
    {
        English = 0,
        German,
        French,
        Spanish,
        Russian
    }
}
