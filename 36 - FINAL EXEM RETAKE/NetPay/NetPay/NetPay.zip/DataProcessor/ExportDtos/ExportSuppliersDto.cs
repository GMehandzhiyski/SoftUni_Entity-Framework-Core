﻿namespace NetPay.DataProcessor.ExportDtos
{
    public class ExportSuppliersDto
    {
        public string SupplierName { get; set; }
    }
}
